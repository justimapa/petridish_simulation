/*
 * prjsv 2015
 * 2014
 * Marco Antognini
 */

#ifndef INFOSV_TYPES_HPP
#define INFOSV_TYPES_HPP

using Quantity   = double;
using Uid        = unsigned int;
///< Unique Identifier, @see createUid()

#endif // INFOSV_TYPES_HPP


Mardi 10.03.2020

Travail en groupe en TP.

Justin & Umut

Nous avons lu et commencé le projet ce jour en salle de TP sur le campus.
La classe CircularBody a été crée, codée et commentée selon les directives.
Nous avons fini la partie 1 du projet.

Umut

J'ai repondu aux questions 1.1 a 1.4.

Dimanche 15.03.2020

Justin & Umut

Nous avons lu le projet et nous avons discuté de la répartition des tâches.
Justin devait faire la partie 2.1 et Umut la partie 2.2.
Justin a aussi mis en place le git pour que les échanges de fichiers soit plus simple.

Lundi 16.03.2020

Justin

J'ai créé les classes Petridish, Lab et Bacterium.
J'ai codé les méthodes demandées dans la partie 2.1 dans les classes Petridish et Lab.

Umut

J'ai crée la classe Nutriment.
J'ai codé les methodes demandées dans la partie 2.2 à faire avant la mise en commun.

Justin & Umut

Nous avons mis en commun et Justin a corrigé les erreurs de compilation qui
sont apparus.

Mardi 17.03.2020

Justin & Umut
Nous avons codé ensemble la croissance et modifié la Classe CircularBody.
Nous avons fini la partie 2 du projet.

Jeudi 19.03.2020

Umut

J'ai netttoyé le code des deux parties (inclusions en trop, fautes de frappes, modularisation,...)
J'ai ajouté toutes les commentaires de la partie 2.
J'ai repondu aux questions 2.1 a 2.4.


Vendredi 20.03.2020

Justin 

J'ai ajouté une méthode refreshConfiguration dans la classe Lab ainsi que
modifié la méthode reset().

Samedi 21.03.2020

Umut

J'ai modifié la fonction reset() de la classe Petridish, pour desallouer
la mémoire alouee dynamiquement par les vecteurs de pointeurs sur des nutriments/bacteries.
J'ai repondu aux question 2.5 a 2.12.

Justin
J'ai modifié le mode debug pour que le nutriment affiche un simple cercle vert
et non et le sprite pour que ce mode soit plus lisible.


Dimanche 22.03.2020

Umut

J'ai codé jusqu'au test 5 de l'étape 3.1.

=======

Dimanche 22.03.2020

Justin
J'ai initializé l'environnement pour la partie 3 du projet ainsi que créé les 
fichiers des classes demandé vide ensuite j'ai codé pour la classe Bacterium jusqu'à la question 3.14.

Umut
J'ai terminé de coder les classes NutrimentA et NutrimentB.
J'ai commencé à coder la classe NutrimentGenerator.

Umut & Justin

Nous avons essayé de trouver une solution pour classe NutrimentGenerator.

Lundi 23.03.2020

Justin
J'ai codé pour la classe Bacterium et SimpleBacterium dans son entièreté.
Il y a eu quelque soucis. La flagelle de SimpleBacterium apparaît mais elle
est peu visible, la simulation semble crasher lorsqu'il y a trop de bacterie
et il arrive qu'une bactérie augmente soudainement de vitesse suite à une
appel de méthode clone().

Umut
J'ai terminé de coder la classe NutrimentGenerator.
J'ai terminé de coder les classes MutableNumber et Mutable Color.

Mardi 23.03.2020

Vendredi 27.03.2020

Umut
J'ai nettoyé le code de la classe CircularBody.

Vendredi 10.04.2020

Umut
J'ai nettoyé le code de la classe Nutriment.

Dimanche 12.04.2020

Umut
J'ai commenté/nettoyé le code des classes NutrimentA/B, NutrimentGenerator et MutableNumber/Color.
J'ai répondu aux questions 3.1 à 3.7.

Jeudi 16.04.2020

Umut
J'ai modifié la méthode reset() de la classe Petridish pour (j'éspère) ne plus avoir de segfaults.
J'ai répondu aux questions 3.15 à 3.20.

Justin

J'ai fini de commenter les classes de la partie 3.

Vendredi 17.04.2020

Justin

J'ai fini de coder les classes Swarm et SwarmBacterium. Je dois encore commenter
le code.
Il y a un bug avec la mise à jour du leader qui doit être régler.
À première vu, je pense qu c'est une erreur avec la gestion des SwarmBacterium
dans le tableau.

Umut

J'ai codé jusqu'au test 13 de la classe TwitchingBacterium.

Samedi 18.04.2020

Umut

J'ai terminé de coder la classe TwitchingBacterium.

Justin 

J'ai corrigé le bug. :)


Dimanche 19.04.2020

Justin

J' ai commenté Swarm and SwarmBacteria et répondu à des questions dans REPONSES.md

Umut

J'ai répondu à deux questions.

Umut et Justin

Rendu intermédiaire!

=======

